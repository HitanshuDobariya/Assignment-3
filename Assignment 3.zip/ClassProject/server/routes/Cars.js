var express = require('express');
var router = express.Router();
//const { router } = require('../config/app');
let Cars = require('../models/Cars');
let CarsController = require('../controllers/Cars')
/* Get route for the Bio Carss list */
// Read Operation
router.get('/', CarsController.DislayCarslist);
/* Get route for Add Cars page --> Create */
router.get('/add', CarsController.AddCars); 
/* Post route for Add Cars page --> Create */
router.post('/add', CarsController.ProcessCars);
/* Get route for displaying the Edit Cars page --> Update */
router.get('/edit/:id', CarsController.EditCars);
/* Post route for processing the Edit Cars page --> Update */
router.post('/edit/:id', CarsController.ProcessEditCars);
/* Get to perform Delete Operation --> Delete Operation */
router.get('/delete/:id', CarsController.DeleteCars);
 module.exports = router;