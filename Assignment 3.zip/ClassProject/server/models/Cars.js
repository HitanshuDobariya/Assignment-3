let mongoose = require('mongoose');

// create a model class
let CarsModel = mongoose.Schema({
    
    name:String,
    make: String,
    color: String,
    price: Number,
    yearOfManufacture: Number,
},
{
    collection:"cars"
});
module.exports = mongoose.model('Cars',CarsModel);
