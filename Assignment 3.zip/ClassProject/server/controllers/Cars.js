var express = require('express');
var router = express.Router();
//const { router } = require('../config/app');
let Cars = require('../models/Cars');

module.exports.DislayCarslist = async (req,res,next)=>{ //< Mark function as async
    try{
       const CarsList = await Cars.find(); //< Use of await keyword
       res.render('Cars/list', {
          title: 'Cars List', 
          CarsList: CarsList
       });
    }catch(err){
       console.error(err);
       //Handle error
       res.render('Cars/list', {
          error: 'Error on server'
       });
    }
 };

 module.exports.AddCars = async (req,res,next)=>{
    try{
        res.render('Cars/add',
        {
            title:'Add Cars'
        })
    }
    catch(err)
    {
        console.error(err);
        res.render('Cars/list',
        {
            error: 'Error on the server'
        });
    }
};

module.exports.ProcessCars = async (req,res,next)=>{
    try{
        let newCars = Cars({
            "name":req.body.Name,
            "make": req.body.make,
            "price": req.body.price,
            "color": req.body.color,
            "yearOfManufacture": req.body.yearofmanufacture
        });
        Cars.create(newCars).then(() =>{
            res.redirect('/Cars')
        })
    }
    catch(error){
        console.error(err);
        res.render('Cars/list',
        {
            error: 'Error on the server'
        });
    }
};

module.exports.EditCars = async (req,res,next)=>{
    try{
    const id = req.params.id;
    const CarsToEdit = await Cars.findById(id);
    res.render('Cars/edit',
    {
        title:'Edit Cars',
        Cars:CarsToEdit
    })
}
catch(error){
    console.error(err);
    res.render('Cars/list',
    {
        error: 'Error on the server'
    });
}
}

module.exports.ProcessEditCars = (req,res,next)=>{
    try{
        const id = req.params.id;
        let updatedCars = Cars({
            "_id":id,
            "name":req.body.name,
            "make": req.body.make,
            "color": req.body.color,
            "price": req.body.price,
            "yearOfManufacture": req.body.yearOfManufacture

            
            
        });
        Cars.findByIdAndUpdate(id,updatedCars).then(()=>{
            res.redirect('/Cars')
        });
    }
    catch(error){
        console.error(err);
        res.render('Cars/list',
        {
            error: 'Error on the server'
        });
    }
}

module.exports.DeleteCars = (req,res,next)=>{
    try{
        let id = req.params.id;
        Cars.deleteOne({_id:id}).then(() =>
        {
            res.redirect('/Cars')
        })
    }
    catch(error){
        console.error(err);
        res.render('Cars',
        {
            error: 'Error on the server'
        });
    }
}